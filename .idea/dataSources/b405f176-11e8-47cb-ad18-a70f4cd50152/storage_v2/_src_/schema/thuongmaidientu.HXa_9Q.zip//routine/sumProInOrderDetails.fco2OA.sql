create
    definer = root@localhost procedure sumProInOrderDetails(IN idOrder decimal)
BEGIN
	select sum(amount) from order_details where id_order_details = idOrder and stt = '1';
END;

