create
    definer = root@localhost procedure getTotalMoneyOrderDetailsByDate_ID_Shop(IN ngay date, IN idShop varchar(50))
BEGIN
	select distinct orde.id_order_details, sum(orde.amount * orde.unit_price) as 'totals' from shop_products s, order_details orde 
	where orde.id_product = s.id_product and date(orde.date_shopaccept) = date(ngay)
	and s.id_shop = idShop and orde.stt = '2' group by orde.id_order_details;
END;

