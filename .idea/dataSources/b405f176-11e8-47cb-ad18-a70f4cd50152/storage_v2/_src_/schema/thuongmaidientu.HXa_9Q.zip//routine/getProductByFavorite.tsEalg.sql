create
    definer = root@localhost procedure getProductByFavorite(IN fv1 int, IN fv2 int, IN fv3 int, IN fv4 int, IN fv5 int)
BEGIN
	SET @type1 = (select p.type_of_product from product p where id_product = fv1);
	SET @type2 = (select p.type_of_product from product p where id_product = fv2);
	SET @type3 = (select p.type_of_product from product p where id_product = fv3);
	SET @type4 = (select p.type_of_product from product p where id_product = fv4);
	SET @type5 = (select p.type_of_product from product p where id_product = fv5);
	(Select p.* from product p
	where p.type_of_product = @type1 and p.status = 1 limit 7)
	UNION 
	(Select p.* from product p
	where p.type_of_product = @type2 and p.status = 1 limit 6)
	union
	(Select p.* from product p
	where p.type_of_product = @type3 and p.status = 1 limit 6)
	union
	(Select p.* from product p
	where p.type_of_product = @type4 and p.status = 1 limit 6)
	union
	(Select p.* from product p
	where p.type_of_product = @type5 and p.status = 1 limit 6);
END;

