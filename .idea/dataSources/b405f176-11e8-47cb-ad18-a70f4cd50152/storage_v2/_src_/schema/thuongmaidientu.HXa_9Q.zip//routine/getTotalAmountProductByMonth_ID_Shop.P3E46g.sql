create
    definer = root@localhost procedure getTotalAmountProductByMonth_ID_Shop(IN ngay date, IN idShop varchar(50))
BEGIN
	select s.id_product, p.name_product ,sum(orde.amount) as 'totalAmount',sum(orde.amount * orde.unit_price) as 'totalMoney' from order_details orde, shop_products s, product p 
	where p.id_product = orde.id_product and s.id_product = orde.id_product and s.id_shop = idShop and orde.stt = '2' and month(orde.date_shopaccept) = month(ngay)
	and year(orde.date_shopaccept) = year(ngay)
	group by s.id_product;
END;

