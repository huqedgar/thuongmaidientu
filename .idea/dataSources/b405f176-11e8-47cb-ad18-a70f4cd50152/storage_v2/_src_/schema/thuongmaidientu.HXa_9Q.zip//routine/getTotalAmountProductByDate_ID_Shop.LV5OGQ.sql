create
    definer = root@localhost procedure getTotalAmountProductByDate_ID_Shop(IN ngay date, IN idShop varchar(50))
BEGIN
	select s.id_product, p.name_product ,sum(orde.amount) as 'totalAmount',sum(orde.amount * orde.unit_price) as 'totalMoney' from order_details orde, shop_products s, product p 
	where p.id_product = orde.id_product and s.id_product = orde.id_product and s.id_shop = idShop and orde.stt = '2' and date(orde.date_shopaccept) = date(ngay)
	group by s.id_product;
END;

