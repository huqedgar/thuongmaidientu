create
    definer = root@localhost procedure GetOrderAcceptedYesterday(IN idShop varchar(50))
BEGIN
	select o.* 
    from order_details o, product p
    where DATE(o.date_shopaccept) = Date(CURDATE()-1) 
    and o.stt = '2' and p.id_product = o.id_product 
    and p.id_shop = idShop
    and p.status = 1
    order by o.id_order_details, o.date_shopaccept desc;
END;

