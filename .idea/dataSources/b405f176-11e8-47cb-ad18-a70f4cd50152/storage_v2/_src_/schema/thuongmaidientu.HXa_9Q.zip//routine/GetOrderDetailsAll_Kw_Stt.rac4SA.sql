create
    definer = root@localhost procedure GetOrderDetailsAll_Kw_Stt(IN idShop varchar(50), IN kw varchar(100),
                                                                 IN stt varchar(50), IN posData int)
BEGIN
	select distinct o.* 
    from order_details o, product p, orders ords
    where o.stt = stt
    and ords.status = stt  
    and ords.id_orders = o.id_order_details
    and p.id_product = o.id_product 
    and p.id_shop = idShop
    and p.name_product like concat('%',kw,'%') or convert(o.date_created, char) like concat('%',kw,'%')
    or (char_length(ords.total_money) = char_length(kw) and convert(ords.total_money, char) = kw) 
    order by o.id_order_details, o.date_created
    limit posData,20;
END;

