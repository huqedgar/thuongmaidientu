create
    definer = root@localhost procedure getEveryNameInOrderSTTByIDCus(IN idCus varchar(50), IN stt varchar(25),
                                                                     IN posData int, IN isFULL varchar(25))
BEGIN
if (isFULL = '' or isFULL like 'FULL' or isFULL = null) then 
	select sp.id_shop from order_details ord, orders o, customers cus, shop_products sp, product p 
	where o.id_orders = ord.id_order_details and ord.id_product = p.id_product and p.id_product = sp.id_product and o.id_customer = cus.id_customer
	and cus.id_customer = idCus and o.status = stt
	group by sp.id_shop;
END IF;
if (isFULL != 'FULL') then 
	select sp.id_shop from order_details ord, orders o, customers cus, shop_products sp, product p 
	where o.id_orders = ord.id_order_details and ord.id_product = p.id_product and p.id_product = sp.id_product and o.id_customer = cus.id_customer
	and cus.id_customer = idCus and o.status = stt
	group by sp.id_shop
    limit posData, 20;
END IF;
END;

