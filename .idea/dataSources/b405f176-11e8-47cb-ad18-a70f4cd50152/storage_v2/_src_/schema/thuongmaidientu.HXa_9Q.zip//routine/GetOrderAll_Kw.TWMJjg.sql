create
    definer = root@localhost procedure GetOrderAll_Kw(IN idShop varchar(50), IN kw varchar(100))
BEGIN
	select distinct o.* 
    from order_details o, product p, orders ords
    where o.stt = '1'
    and ords.status = '1'  
    and ords.id_orders = o.id_order_details
    and p.id_product = o.id_product 
    and p.id_shop = idShop
    and p.name_product like concat('%',kw,'%') or convert(o.date_created, char) like concat('%',kw,'%')
    or (char_length(ords.total_money) = char_length(kw) and convert(ords.total_money, char) = kw) 
    order by o.id_order_details, o.date_created
    limit 0,20;
END;

