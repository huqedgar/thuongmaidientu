create
    definer = root@localhost procedure getFullOrderWaittingByIDShop(IN idShop varchar(50), IN statuss varchar(50),
                                                                    IN time_kw varchar(50), IN posData int)
BEGIN
if(time_kw = '')
then
	(select o.id_order_details, count(o.id_order_details) from orders ord, order_details o, shop_products s where o.id_product = s.id_product and s.id_shop = idShop and o.stt = statuss
	and ord.id_orders = o.id_order_details and ord.status != 'Waitting'
    group by o.id_order_details
	order by o.id_order_details
    limit posData,20);
    elseif (time_kw = 'today') then
		(select o.id_order_details, count(o.id_order_details) from orders ord, order_details o, shop_products s where o.id_product = s.id_product and s.id_shop = idShop and o.stt = statuss
		and ord.id_orders = o.id_order_details and ord.status != 'Waitting' and DATE(o.date_created) >= Date(CURDATE())
		group by o.id_order_details
		order by o.id_order_details
        limit posData,20);
    elseif (time_kw = 'yesterday') then
		(select o.id_order_details, count(o.id_order_details) from orders ord, order_details o, shop_products s where o.id_product = s.id_product and s.id_shop = idShop and o.stt = statuss
		and ord.id_orders = o.id_order_details and ord.status != 'Waitting' and DATE(o.date_created) = Date(CURDATE()-1) 
		group by o.id_order_details
		order by o.id_order_details
        limit posData,20);
    elseif (time_kw = 'moreday') then
		(select o.id_order_details, count(o.id_order_details) from orders ord, order_details o, shop_products s where o.id_product = s.id_product and s.id_shop = idShop and o.stt = statuss
		and ord.id_orders = o.id_order_details and ord.status != 'Waitting' and DATE(o.date_created) <= Date(CURDATE()-2) 
		group by o.id_order_details
		order by o.id_order_details
        limit posData,20);
	elseif (time_kw = 'full') then
		(select o.id_order_details, count(o.id_order_details) from orders ord, order_details o, shop_products s where o.id_product = s.id_product and s.id_shop = idShop and o.stt = statuss
		and ord.id_orders = o.id_order_details and ord.status != 'Waitting' 
		group by o.id_order_details
		order by o.id_order_details);
end if;
END;

