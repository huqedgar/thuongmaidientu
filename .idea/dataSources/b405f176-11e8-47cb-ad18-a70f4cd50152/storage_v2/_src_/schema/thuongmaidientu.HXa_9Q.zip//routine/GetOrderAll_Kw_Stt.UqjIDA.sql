create
    definer = root@localhost procedure GetOrderAll_Kw_Stt(IN idShop varchar(50), IN kw varchar(100), IN stt varchar(50),
                                                          IN posData int, IN INCRE_DES varchar(50))
BEGIN
	if (INCRE_DES = '' or INCRE_DES like 'INCRE' or INCRE_DES = null) then 
		select distinct ords.*
		from order_details o, product p, orders ords
		where 
		(ords.status = stt 
		and ords.id_orders = o.id_order_details
		and p.id_product = o.id_product 
		and p.id_shop = idShop
		and p.name_product like concat('%',kw,'%'))
		or 
		(convert(ords.time_booked, char) like concat('%',kw,'%') 
		and ords.status = stt
		and ords.id_orders = o.id_order_details
		and p.id_product = o.id_product 
		and p.id_shop = idShop)
		or 
		(char_length(ords.total_money) = char_length(kw) and convert(ords.total_money, char) = kw
		and ords.status = stt
		and ords.id_orders = o.id_order_details
		and p.id_product = o.id_product 
		and p.id_shop = idShop) 
		group by ords.id_orders
		order by ords.time_booked
		limit posData,20;
    END IF;
	if (INCRE_DES like 'DES') then 
		select distinct ords.*
		from order_details o, product p, orders ords
		where 
		(ords.status = stt 
		and ords.id_orders = o.id_order_details
		and p.id_product = o.id_product 
		and p.id_shop = idShop
		and p.name_product like concat('%',kw,'%'))
		or 
		(convert(ords.time_booked, char) like concat('%',kw,'%') 
		and ords.status = stt
		and ords.id_orders = o.id_order_details
		and p.id_product = o.id_product 
		and p.id_shop = idShop)
		or 
		(char_length(ords.total_money) = char_length(kw) and convert(ords.total_money, char) = kw
		and ords.status = stt
		and ords.id_orders = o.id_order_details
		and p.id_product = o.id_product 
		and p.id_shop = idShop) 
		group by ords.id_orders
		order by ords.time_booked desc
		limit posData,20;
    END IF;
    if (INCRE_DES like 'FULL') then 
		select distinct ords.*
		from order_details o, product p, orders ords
		where 
		(ords.status = stt 
		and ords.id_orders = o.id_order_details
		and p.id_product = o.id_product 
		and p.id_shop = idShop
		and p.name_product like concat('%',kw,'%'))
		or 
		(convert(ords.time_booked, char) like concat('%',kw,'%') 
		and ords.status = stt
		and ords.id_orders = o.id_order_details
		and p.id_product = o.id_product 
		and p.id_shop = idShop)
		or 
		(char_length(ords.total_money) = char_length(kw) and convert(ords.total_money, char) = kw
		and ords.status = stt
		and ords.id_orders = o.id_order_details
		and p.id_product = o.id_product 
		and p.id_shop = idShop) 
		group by ords.id_orders
		order by ords.time_booked;
    END IF;
END;

