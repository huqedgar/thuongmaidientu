create
    definer = root@localhost procedure confirmOrderReportByShop(IN idShop varchar(50), IN idPro int)
BEGIN
	update report r set r.stt = '2', r.date_solve = NOW() where r.id_product = idPro and r.id_shop_store = idShop;
END;

