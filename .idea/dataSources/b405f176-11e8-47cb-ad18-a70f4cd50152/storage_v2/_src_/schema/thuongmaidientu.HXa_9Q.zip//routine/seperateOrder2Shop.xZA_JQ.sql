create
    definer = root@localhost procedure seperateOrder2Shop(IN idOrdWaiting mediumtext, IN idShop varchar(50),
                                                          IN idOrdeNew mediumtext)
BEGIN
	update order_details o, shop_products sh set o.id_order_details = idOrdeNew where o.id_product = sh.id_product  and sh.id_shop = idShop  and o.id_order_details = idOrdWaiting;
END;

