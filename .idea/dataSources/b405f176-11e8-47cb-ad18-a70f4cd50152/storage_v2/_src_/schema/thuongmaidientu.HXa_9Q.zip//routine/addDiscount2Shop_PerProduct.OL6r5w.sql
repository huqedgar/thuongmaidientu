create
    definer = root@localhost procedure addDiscount2Shop_PerProduct(IN idPro int, IN idDis varchar(25))
BEGIN
	update shop_products s set s.id_discount = idDis where s.id_product = idPro;
END;

