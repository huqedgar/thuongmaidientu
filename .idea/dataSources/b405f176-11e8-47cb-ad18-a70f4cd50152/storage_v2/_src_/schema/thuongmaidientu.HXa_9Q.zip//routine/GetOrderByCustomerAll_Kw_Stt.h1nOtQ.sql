create
    definer = root@localhost procedure GetOrderByCustomerAll_Kw_Stt(IN idCus varchar(50), IN kw varchar(100),
                                                                    IN stt varchar(50), IN posData int,
                                                                    IN INCRE_DES varchar(50))
BEGIN
	if (INCRE_DES = '' or INCRE_DES like 'INCRE' or INCRE_DES = null) then 
		select distinct ords.*
		from orders ords, customers cus
		where 
		(ords.status = stt 
		and cus.id_customer = idCus
		and convert(ords.id_orders, char) like concat('%',kw,'%'))
		or 
		(convert(ords.time_booked, char) like concat('%',kw,'%') 
		and ords.status = stt
		and cus.id_customer = idCus)
		or 
		(char_length(ords.total_money) = char_length(kw) and convert(ords.total_money, char) = kw
		and ords.status = stt
		and cus.id_customer = idCus) 
		group by ords.id_orders
		order by ords.time_booked
		limit posData,20;
    END IF;
	if (INCRE_DES like 'DES') then 
		select distinct ords.*
		from orders ords, customers cus
		where 
		(ords.status = stt 
		and cus.id_customer = idCus
		and convert(ords.id_orders, char) like concat('%',kw,'%'))
		or 
		(convert(ords.time_booked, char) like concat('%',kw,'%') 
		and ords.status = stt
		and cus.id_customer = idCus)
		or 
		(char_length(ords.total_money) = char_length(kw) and convert(ords.total_money, char) = kw
		and ords.status = stt
		and cus.id_customer = idCus) 
		group by ords.id_orders
		order by ords.time_booked desc
		limit posData,20;
    END IF;
    if (INCRE_DES like 'FULL') then 
		select distinct ords.*
		from orders ords, customers cus
		where 
		(ords.status = stt 
		and cus.id_customer = idCus
		and convert(ords.id_orders, char) like concat('%',kw,'%'))
		or 
		(convert(ords.time_booked, char) like concat('%',kw,'%') 
		and ords.status = stt
		and cus.id_customer = idCus)
		or 
		(char_length(ords.total_money) = char_length(kw) and convert(ords.total_money, char) = kw
		and ords.status = stt
		and cus.id_customer = idCus) 
		group by ords.id_orders
		order by ords.time_booked;
    END IF;
END;

