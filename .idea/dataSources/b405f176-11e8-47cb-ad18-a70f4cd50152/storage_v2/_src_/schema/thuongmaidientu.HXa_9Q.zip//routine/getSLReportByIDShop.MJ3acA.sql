create
    definer = root@localhost procedure getSLReportByIDShop(IN idShop varchar(100), IN stt_rp int)
BEGIN
	SELECT id_shop_store,count(id_rp) FROM thuongmaidientu.report where stt = stt_rp and id_shop_store = idShop group by id_shop_store;
END;

