create
    definer = root@localhost procedure GetOrderToday(IN ngay date, IN idShop varchar(50))
BEGIN
	select o.* 
    from order_details o, product p
    where DATE(o.date_created) >= ngay 
    and o.stt = '1' and p.id_product = o.id_product 
    and p.id_shop = idShop
    and p.status = 1
    order by o.id_order_details, o.date_created;
END;

