create
    definer = root@localhost procedure getSLProductCanTBuyByIDShop(IN idShop varchar(100), IN stt_pro int)
BEGIN
	SELECT id_shop,count(id_product) FROM thuongmaidientu.product where status = stt_pro and id_shop = idShop group by id_shop;
END;

