create
    definer = root@localhost procedure getProductFavoriteOfCustomer(IN idCus varchar(50))
BEGIN
	select customers.id_customer,order_details.id_product ,count(order_details.id_product) as 'AmountOrder', sum(order_details.amount) as 'AmountPro' from order_details, orders, customers where order_details.id_order_details = orders.id_orders
	and customers.id_customer = orders.id_customer and customers.id_customer = idCus
	group by customers.id_customer, order_details.id_product
	order by count(order_details.id_product) desc;
END;

