create
    definer = root@localhost procedure getIn4ShopAndSLProductCanBuy(IN kw varchar(100), IN posData int)
BEGIN
	(select st.id_shop_store,st.name_store,st.date_begin,  count(p.id_product) as 'slproduct_can' from shop_store st, shop_products sp, product p
	where st.id_shop_store = sp.id_shop and p.id_product = sp.id_product and p.id_shop = st.id_shop_store and p.status = 1
	group by st.id_shop_store
	limit posData,8)
    union
    (select st.id_shop_store,st.name_store,st.date_begin, 0 as 'slproduct_can' from shop_store st, shop_products sp, product p
    where st.id_shop_store not in (select st_sub.id_shop_store from shop_store st_sub, shop_products sp_sub, product p_sub
	where st_sub.id_shop_store = sp_sub.id_shop and p_sub.id_product = sp_sub.id_product and p_sub.id_shop = st_sub.id_shop_store and p_sub.status = 1
	group by st_sub.id_shop_store)
	group by st.id_shop_store
	limit posData,8);
END;

