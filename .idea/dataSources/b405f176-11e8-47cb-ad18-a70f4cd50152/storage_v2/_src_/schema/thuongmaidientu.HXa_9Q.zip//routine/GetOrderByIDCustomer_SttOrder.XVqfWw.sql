create
    definer = root@localhost procedure GetOrderByIDCustomer_SttOrder(IN idCus varchar(50), IN stt varchar(100))
BEGIN
	SELECT ord.* 
    FROM order_details ord, orders o 
    where o.id_customer = idCus  
    and o.id_orders = ord.id_order_details 
    and o.status = stt
    order by o.time_booked
    limit 0,20;
END;

